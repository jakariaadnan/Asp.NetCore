﻿using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace MdJakariaAdnan9thExamProject1252834.Models
{
    public class dbMobileShopDbContext : DbContext
    {
        public dbMobileShopDbContext(DbContextOptions<dbMobileShopDbContext> op) : base(op)
        {

        }
        public DbSet<MobileCompany> Companies { get; set; }
        public DbSet<MobileModel> Mobiles { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<Payments> Payments { get; set; }
        public DbSet<DeliveryBoy> DeliveryBoys { get; set; }
        public DbSet<DeliveryDetails> DeliveryDetails { get; set; }
    }
    public class MobileCompany
    {
        [Key]
        public int Id { get; set; }
        [Required, DisplayName("Company Name"), StringLength(50)]
        public string CompanyName { get; set; }
        public ICollection<MobileModel> mobileModels { get; set; }
    }
    public class MobileModel
    {
        [Key]
        public int Id { get; set; }
        [Required, ForeignKey("MobileCompany")]
        public int MobileCompanyID { get; set; }
        [Required, DisplayName("Model Name"), StringLength(50)]
        public string ModelName { get; set; }
        public string Processor { get; set; }
        public string Chipset { get; set; }
        [Required]
        public string RAM { get; set; }
        public string ROM { get; set; }
        public string Network { get; set; }
        public string SIM { get; set; }
        public string Display { get; set; }
        [DisplayName("Font Camera"), StringLength(50)]
        public string FontCamera { get; set; }
        [Required, DisplayName("Back Camera"), StringLength(50)]
        public string BackCamera { get; set; }
        public string Bettery { get; set; }
        [DisplayName("Release Year"), StringLength(50)]
        public string ReleaseYear { get; set; }
        public string Price { get; set; }
        public string Photo { get; set; }
        [NotMapped]
        public IFormFile imgFile { get; set; }
        public ICollection<Order> Orders { get; set; }

        public virtual MobileCompany MobileCompany { get; set; }
    }
    
    public class Order
    {
        [Key]
        public int OrderId { get; set; }
        [Required, ForeignKey("MobileModel")]
        public int MobileId { get; set; }
        [Required, DisplayName("UserEmail")]
        public string UserEmail { get; set; }
        public int Price { get; set; }
        public int Quantity { get; set; }
        public int Total { get; set; }
        [DataType(DataType.Date), Display(Name = "Order Date")]
        public DateTime OrderTime { get; set; }
        public string Status { get; set; }
        [DisplayName("Payment Methode")]
        public string PaymentMethode { get; set; }

        public ICollection<Payments> Payments { get; set; }
        public virtual MobileModel MobileModels { get; set; }
    }
    public class Payments
    {
        [Key]
        public int Id { get; set; }
        [Required, StringLength(15)]
        public string Method { get; set; }
        public int TransectionId { get; set; }
        [Required, ForeignKey("Order")]
        public int OrderId { get; set; }
        [DisplayName("Total Price")]
        public int TotalPrice { get; set; }
        [DisplayName("User Email")]
        public string UserEmail { get; set; }

        public virtual Order Orders { get; set; }
    }
    public class DeliveryBoy
    {
        [Key]
        public int Id { get; set; }
        [Required, StringLength(50)]
        public string Name { get; set; }
        public string Area { get; set; }
        [Required, DisplayName("Contact Number")]
        public string ContactNumber { get; set; }

        public ICollection<DeliveryDetails> deliveryDetails { get; set; }
    }    

    public class DeliveryDetails
    {
        [Key]
        public int Id { get; set; }
        [Required, DisplayName("Delivery Boy Id"), ForeignKey("MobileCompany")]
        public int DeliveryBoyId { get; set; }
        [Required, ForeignKey("Order")]
        public int OrderId { get; set; }
        [DisplayName("User Email")]
        public string UserEmail { get; set; }
        [Required]
        public string Status { get; set; }

        public virtual Order Orders { get; set; }

        public virtual DeliveryBoy DeliveryBoys { get; set; }
    }

}
