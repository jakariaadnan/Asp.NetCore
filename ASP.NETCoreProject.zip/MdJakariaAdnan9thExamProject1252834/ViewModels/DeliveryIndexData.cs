﻿using MdJakariaAdnan9thExamProject1252834.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MdJakariaAdnan9thExamProject1252834.ViewModels
{
    public class DeliveryIndexData
    {
        public ICollection<DeliveryBoy> deliveryBoys { get; set; }
        public ICollection<Order> orders { get; set; }
        public ICollection<DeliveryDetails> DeliveryDetails { get; set; }
    }
}
