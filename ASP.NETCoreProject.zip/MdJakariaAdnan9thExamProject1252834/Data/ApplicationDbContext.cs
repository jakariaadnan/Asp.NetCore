﻿using System;
using System.Collections.Generic;
using System.Text;
using MdJakariaAdnan9thExamProject1252834.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace MdJakariaAdnan9thExamProject1252834.Data
{
    public class ApplicationDbContext : IdentityDbContext<IdentityModel>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
    }
}
