﻿using System;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace MdJakariaAdnan9thExamProject1252834.Migrations
{
    public partial class Initil5 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Companies",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CompanyName = table.Column<string>(maxLength: 50, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Companies", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "DeliveryBoys",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Name = table.Column<string>(maxLength: 50, nullable: false),
                    Area = table.Column<string>(nullable: true),
                    ContactNumber = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DeliveryBoys", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Mobiles",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    MobileCompanyID = table.Column<int>(nullable: false),
                    ModelName = table.Column<string>(maxLength: 50, nullable: false),
                    Processor = table.Column<string>(nullable: true),
                    Chipset = table.Column<string>(nullable: true),
                    RAM = table.Column<string>(nullable: false),
                    ROM = table.Column<string>(nullable: true),
                    Network = table.Column<string>(nullable: true),
                    SIM = table.Column<string>(nullable: true),
                    Display = table.Column<string>(nullable: true),
                    FontCamera = table.Column<string>(maxLength: 50, nullable: true),
                    BackCamera = table.Column<string>(maxLength: 50, nullable: false),
                    Bettery = table.Column<string>(nullable: true),
                    ReleaseYear = table.Column<string>(maxLength: 50, nullable: true),
                    Price = table.Column<string>(nullable: true),
                    Photo = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Mobiles", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Mobiles_Companies_MobileCompanyID",
                        column: x => x.MobileCompanyID,
                        principalTable: "Companies",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Orders",
                columns: table => new
                {
                    OrderId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    MobileId = table.Column<int>(nullable: false),
                    UserEmail = table.Column<string>(nullable: true),
                    Price = table.Column<int>(nullable: false),
                    Quantity = table.Column<int>(nullable: false),
                    Total = table.Column<int>(nullable: false),
                    OrderTime = table.Column<DateTime>(nullable: false),
                    Status = table.Column<string>(nullable: true),
                    PaymentMethode = table.Column<string>(nullable: true),
                    MobileModelsId = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Orders", x => x.OrderId);
                    table.ForeignKey(
                        name: "FK_Orders_Mobiles_MobileModelsId",
                        column: x => x.MobileModelsId,
                        principalTable: "Mobiles",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "DeliveryDetails",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    DeliveryBoyId = table.Column<int>(nullable: false),
                    OrderId = table.Column<int>(nullable: false),
                    UserEmail = table.Column<string>(nullable: true),
                    Status = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DeliveryDetails", x => x.Id);
                    table.ForeignKey(
                        name: "FK_DeliveryDetails_DeliveryBoys_DeliveryBoyId",
                        column: x => x.DeliveryBoyId,
                        principalTable: "DeliveryBoys",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_DeliveryDetails_Orders_OrderId",
                        column: x => x.OrderId,
                        principalTable: "Orders",
                        principalColumn: "OrderId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Payments",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Method = table.Column<string>(maxLength: 15, nullable: false),
                    TransectionId = table.Column<int>(nullable: false),
                    OrderId = table.Column<int>(nullable: false),
                    TotalPrice = table.Column<int>(nullable: false),
                    UserEmail = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Payments", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Payments_Orders_OrderId",
                        column: x => x.OrderId,
                        principalTable: "Orders",
                        principalColumn: "OrderId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_DeliveryDetails_DeliveryBoyId",
                table: "DeliveryDetails",
                column: "DeliveryBoyId");

            migrationBuilder.CreateIndex(
                name: "IX_DeliveryDetails_OrderId",
                table: "DeliveryDetails",
                column: "OrderId");

            migrationBuilder.CreateIndex(
                name: "IX_Mobiles_MobileCompanyID",
                table: "Mobiles",
                column: "MobileCompanyID");

            migrationBuilder.CreateIndex(
                name: "IX_Orders_MobileModelsId",
                table: "Orders",
                column: "MobileModelsId");

            migrationBuilder.CreateIndex(
                name: "IX_Payments_OrderId",
                table: "Payments",
                column: "OrderId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "DeliveryDetails");

            migrationBuilder.DropTable(
                name: "Payments");

            migrationBuilder.DropTable(
                name: "DeliveryBoys");

            migrationBuilder.DropTable(
                name: "Orders");

            migrationBuilder.DropTable(
                name: "Mobiles");

            migrationBuilder.DropTable(
                name: "Companies");
        }
    }
}
