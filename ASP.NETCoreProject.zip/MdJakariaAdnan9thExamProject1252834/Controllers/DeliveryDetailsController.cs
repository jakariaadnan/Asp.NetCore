﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using MdJakariaAdnan9thExamProject1252834.Models;
using Microsoft.AspNetCore.Authorization;

namespace MdJakariaAdnan9thExamProject1252834.Controllers
{
    public class DeliveryDetailsController : Controller
    {
        private readonly dbMobileShopDbContext _context;

        public DeliveryDetailsController(dbMobileShopDbContext context)
        {
            _context = context;
        }

        // GET: DeliveryDetails
        public async Task<IActionResult> Index()
        {
            var dbMobileShopDbContext = _context.DeliveryDetails.Include(d => d.DeliveryBoys).Include(d => d.Orders);
            return View(await dbMobileShopDbContext.ToListAsync());
        }

        // GET: DeliveryDetails/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var deliveryDetails = await _context.DeliveryDetails
                .Include(d => d.DeliveryBoys)
                .Include(d => d.Orders)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (deliveryDetails == null)
            {
                return NotFound();
            }

            return View(deliveryDetails);
        }

        // GET: DeliveryDetails/Create
        [Authorize(Roles = "Admin")]
        public IActionResult Create()
        {
            ViewData["DeliveryBoyId"] = new SelectList(_context.DeliveryBoys, "Id", "ContactNumber");
            ViewData["OrderId"] = new SelectList(_context.Orders, "OrderId", "OrderId");
            return View();
        }

        // POST: DeliveryDetails/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,DeliveryBoyId,OrderId,UserEmail,Status")] DeliveryDetails deliveryDetails)
        {
            if (ModelState.IsValid)
            {
                _context.Add(deliveryDetails);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["DeliveryBoyId"] = new SelectList(_context.DeliveryBoys, "Id", "ContactNumber", deliveryDetails.DeliveryBoyId);
            ViewData["OrderId"] = new SelectList(_context.Orders, "OrderId", "OrderId", deliveryDetails.OrderId);
            return View(deliveryDetails);
        }

        // GET: DeliveryDetails/Edit/5
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var deliveryDetails = await _context.DeliveryDetails.FindAsync(id);
            if (deliveryDetails == null)
            {
                return NotFound();
            }
            ViewData["DeliveryBoyId"] = new SelectList(_context.DeliveryBoys, "Id", "ContactNumber", deliveryDetails.DeliveryBoyId);
            ViewData["OrderId"] = new SelectList(_context.Orders, "OrderId", "OrderId", deliveryDetails.OrderId);
            return View(deliveryDetails);
        }

        // POST: DeliveryDetails/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,DeliveryBoyId,OrderId,UserEmail,Status")] DeliveryDetails deliveryDetails)
        {
            if (id != deliveryDetails.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(deliveryDetails);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!DeliveryDetailsExists(deliveryDetails.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["DeliveryBoyId"] = new SelectList(_context.DeliveryBoys, "Id", "ContactNumber", deliveryDetails.DeliveryBoyId);
            ViewData["OrderId"] = new SelectList(_context.Orders, "OrderId", "OrderId", deliveryDetails.OrderId);
            return View(deliveryDetails);
        }

        // GET: DeliveryDetails/Delete/5
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var deliveryDetails = await _context.DeliveryDetails
                .Include(d => d.DeliveryBoys)
                .Include(d => d.Orders)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (deliveryDetails == null)
            {
                return NotFound();
            }

            return View(deliveryDetails);
        }

        // POST: DeliveryDetails/Delete/5
        [Authorize(Roles = "Admin")]
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var deliveryDetails = await _context.DeliveryDetails.FindAsync(id);
            _context.DeliveryDetails.Remove(deliveryDetails);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool DeliveryDetailsExists(int id)
        {
            return _context.DeliveryDetails.Any(e => e.Id == id);
        }
    }
}
