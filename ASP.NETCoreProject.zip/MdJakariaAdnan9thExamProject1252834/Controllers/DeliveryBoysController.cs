﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using MdJakariaAdnan9thExamProject1252834.Models;
using Microsoft.AspNetCore.Authorization;

namespace MdJakariaAdnan9thExamProject1252834.Controllers
{
    public class DeliveryBoysController : Controller
    {
        private readonly dbMobileShopDbContext _context;

        public DeliveryBoysController(dbMobileShopDbContext context)
        {
            _context = context;
        }

        // GET: DeliveryBoys
        public async Task<IActionResult> Index()
        {
            return View(await _context.DeliveryBoys.ToListAsync());
        }

        // GET: DeliveryBoys/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var deliveryBoy = await _context.DeliveryBoys
                .FirstOrDefaultAsync(m => m.Id == id);
            if (deliveryBoy == null)
            {
                return NotFound();
            }

            return View(deliveryBoy);
        }

        // GET: DeliveryBoys/Create
        [Authorize(Roles = "Admin")]
        public IActionResult Create()
        {
            return View();
        }

        // POST: DeliveryBoys/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(List< DeliveryBoy> deliveryBoy)
        {
            if (ModelState.IsValid)
            {
                _context.AddRange(deliveryBoy);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(deliveryBoy);
        }

        // GET: DeliveryBoys/Edit/5
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var deliveryBoy = await _context.DeliveryBoys.FindAsync(id);
            if (deliveryBoy == null)
            {
                return NotFound();
            }
            return View(deliveryBoy);
        }

        // POST: DeliveryBoys/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Name,Area,ContactNumber")] DeliveryBoy deliveryBoy)
        {
            if (id != deliveryBoy.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(deliveryBoy);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!DeliveryBoyExists(deliveryBoy.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(deliveryBoy);
        }

        // GET: DeliveryBoys/Delete/5
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var deliveryBoy = await _context.DeliveryBoys
                .FirstOrDefaultAsync(m => m.Id == id);
            if (deliveryBoy == null)
            {
                return NotFound();
            }

            return View(deliveryBoy);
        }

        // POST: DeliveryBoys/Delete/5
        [Authorize(Roles = "Admin")]
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var deliveryBoy = await _context.DeliveryBoys.FindAsync(id);
            _context.DeliveryBoys.Remove(deliveryBoy);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool DeliveryBoyExists(int id)
        {
            return _context.DeliveryBoys.Any(e => e.Id == id);
        }
    }
}
