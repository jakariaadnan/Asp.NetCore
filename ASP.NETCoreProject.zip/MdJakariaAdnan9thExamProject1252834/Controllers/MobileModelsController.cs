﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using MdJakariaAdnan9thExamProject1252834.Models;
using Microsoft.AspNetCore.Hosting;
using System.IO;
using Microsoft.AspNetCore.Authorization;

namespace MdJakariaAdnan9thExamProject1252834.Controllers
{
    public class MobileModelsController : Controller
    {
        private readonly dbMobileShopDbContext _context;
        private readonly IHostingEnvironment hosting;
        public MobileModelsController(dbMobileShopDbContext context, IHostingEnvironment _hosting)
        {
            _context = context;
            hosting = _hosting;
        }

        // GET: MobileModels
        public async Task<IActionResult> Index(string sortOrder, string currentFilter, string searchString, int? pageNumber)
        {
            ViewData["NameSortParm"] = String.IsNullOrEmpty(sortOrder) ? "name_desc" : "";
            ViewData["DateSortParm"] = sortOrder == "Date" ? "date_desc" : "Date";
            ViewData["CurrentFilter"] = searchString;
            ViewData["CurrentSort"] = sortOrder;
            if (searchString != null)
            {
                pageNumber = 1;
            }
            else
            {
                searchString = currentFilter;
            }
            var mobiles = from s in _context.Mobiles
                           select s;
            if (!String.IsNullOrEmpty(searchString))
            {
                mobiles = mobiles.Where(m => m.ModelName.Contains(searchString)
                                       || m.Processor.Contains(searchString)
                                       || m.RAM.Contains(searchString)
                                       || m.ROM.Contains(searchString)
                                       || m.SIM.Contains(searchString)
                                       || m.Display.Contains(searchString)
                                       || m.FontCamera.Contains(searchString)
                                       || m.BackCamera.Contains(searchString)
                                       || m.Bettery.Contains(searchString));
            }
            switch (sortOrder)
            {
                case "name_desc":
                    mobiles = mobiles.OrderByDescending(s => s.ModelName);
                    break;
                case "Date":
                    mobiles = mobiles.OrderBy(s => s.ReleaseYear);
                    break;
                case "date_desc":
                    mobiles = mobiles.OrderByDescending(s => s.ReleaseYear);
                    break;
                default:
                    mobiles = mobiles.OrderBy(s => s.ModelName);
                    break;
            }
            int pageSize = 3;
            return View(await PaginatedList<MobileModel>.CreateAsync(mobiles.AsNoTracking(), pageNumber ?? 1, pageSize));
            //return View(await _context.Mobiles.ToListAsync());
        }

        // GET: MobileModels/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var mobileModel = await _context.Mobiles
                .FirstOrDefaultAsync(m => m.Id == id);
            if (mobileModel == null)
            {
                return NotFound();
            }

            return View(mobileModel);
        }

        // GET: MobileModels/Create
        [Authorize(Roles = "Admin")]
        public IActionResult Create()
        {
            ViewBag.Result = new SelectList(_context.Companies, "Id", "CompanyName");
            return View();
        }

        // POST: MobileModels/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create( MobileModel mobileModel)
        {
            
            if (ModelState.IsValid)
            {
                if (mobileModel != null)
                {
                    if (mobileModel.imgFile != null)
                    {
                        string ext = Path.GetExtension(mobileModel.imgFile.FileName).ToLower();
                        if (ext == ".png" || ext == ".jpg" || ext == ".jpeg")
                        {
                            string fileName = Path.GetFileNameWithoutExtension(mobileModel.imgFile.FileName);
                            string file = Guid.NewGuid() + "_" + fileName + ext;
                            var filePath = Path.Combine(hosting.WebRootPath, "images\\MobilePhoto", file);
                            using (var fileStream = new FileStream(filePath, FileMode.Create))
                            {
                                mobileModel.imgFile.CopyTo(fileStream);
                            }
                            mobileModel.Photo = "~/images/MobilePhoto/" + file;
                        }
                    }
                }
                _context.Add(mobileModel);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewBag.Result = new SelectList(_context.Companies, "Id", "CompanyName",mobileModel.MobileCompanyID);

            return View(mobileModel);
        }

        // GET: MobileModels/Edit/5
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Edit(int? id)
        {
            ViewBag.Result = new SelectList(_context.Companies, "Id", "CompanyName");
            if (id == null)
            {
                return NotFound();
            }

            var mobileModel = await _context.Mobiles.FindAsync(id);
            if (mobileModel == null)
            {
                return NotFound();
            }
            return View(mobileModel);
        }

        // POST: MobileModels/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, MobileModel mobileModel)
        {
            ViewBag.Result = new SelectList(_context.Companies, "Id", "CompanyName", mobileModel.MobileCompanyID);
            if (id != mobileModel.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    if (mobileModel != null)
                    {
                        if (mobileModel.imgFile != null)
                        {
                            string ext = Path.GetExtension(mobileModel.imgFile.FileName).ToLower();
                            if (ext == ".png" || ext == ".jpg" || ext == ".jpeg")
                            {
                                string fileName = Path.GetFileNameWithoutExtension(mobileModel.imgFile.FileName);
                                string file = Guid.NewGuid() + "_" + fileName + ext;
                                var filePath = Path.Combine(hosting.WebRootPath, "images\\MobilePhoto", file);
                                using (var fileStream = new FileStream(filePath, FileMode.Create))
                                {
                                    mobileModel.imgFile.CopyTo(fileStream);
                                }
                                mobileModel.Photo = "~/images/MobilePhoto/" + file;
                            }
                        }
                        else
                        {
                            mobileModel.Photo = mobileModel.Photo;
                        }
                    }
                    _context.Update(mobileModel);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!MobileModelExists(mobileModel.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(mobileModel);
        }

        // GET: MobileModels/Delete/5
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var mobileModel = await _context.Mobiles
                .FirstOrDefaultAsync(m => m.Id == id);
            if (mobileModel == null)
            {
                return NotFound();
            }

            return View(mobileModel);
        }

        // POST: MobileModels/Delete/5
        [Authorize(Roles = "Admin")]
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var mobileModel = await _context.Mobiles.FindAsync(id);
            _context.Mobiles.Remove(mobileModel);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool MobileModelExists(int id)
        {
            return _context.Mobiles.Any(e => e.Id == id);
        }
    }
}
